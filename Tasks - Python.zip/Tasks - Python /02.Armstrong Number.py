digits = int(input("Enter Size Of Digits"))
num = int(input("Enter Range Of Your series"))
total = 0
data = []
if count(num) == digits:
    for i in str(num):
        data.append(int(i) ** digits)
    print(sum(data))
    print(data)
    if sum(data) == num:
        print("Armstrong Number
    else:
        print("Not Armstrong Number")
else:
     print("Enter Your selected digits")