
# 6) program to check if a number is even or odd
num = int(input("Enter A Number"))
if num > 1:
    if num % 2 == 0:
        print("Number Is Even")
    else:
        print("Number Is Odd")
else:
    print("Enter Valid Number")