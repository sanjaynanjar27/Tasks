name1 = [5, 6, 8]
name2 = [3, 9, 7]
for i in range(len(name1)):
    if name1[i] > name2[i]:
        print(1, end=' ')
    elif name1[i] == name2[i]:
        print(end=' ')
    else:
        print(1, end=' ')